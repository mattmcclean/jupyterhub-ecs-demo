import os

from traitlets import Bool, Unicode, List, Dict

from jupyterhub.spawner import Spawner

from tornado import gen

import boto3

start_states = [ 'PROVISIONING', 'PENDING', 'ACTIVATING', 'RUNNING' ]

class EcsSpawner(Spawner):

    ecs_cluser_name = Unicode(
        os.environ.get('ECS_CLUSTER', None),
        help="""
        The short name or full Amazon Resource Name (ARN) of the cluster on which to run your task.
        """
    ).tag(config=True)

    task_definition_arn = Unicode(
        os.environ.get('TASK_DEF_ARN', None),
        help="""
        The family and revision (family:revision) or full ARN of the task definition to run. 
        """
    ).tag(config=True)

    region = Unicode(
        os.environ.get('AWS_REGION', 'us-east-1'),
        help="""
        The region to launch the ECS Task into. 
        """
    ).tag(config=True)    

    container_overrides = Dict(
        None,
        allow_none=True,
        help="""
        A list of container overrides in JSON format that specify the name of a container 
        in the specified task definition and the overrides it should receive.
        """,
    ).tag(config=True)

    group = Unicode(
        None,
        allow_none=True,
        help="""
        The name of the task group to associate with the task. 
        """
    ).tag(config=True)    

    placement_constraints = List(
        None,
        allow_none=True,
        help="""
        An array of placement constraint objects to use for the task. 
        """        
    ).tag(config=True)    

    placement_strategy = List(
        None,
        allow_none=True,
        help="""
        The placement strategy objects to use for the task. 
        """        
    ).tag(config=True)        

    launch_type = Unicode(
        'FARGATE',
        help="""
        The launch type on which to run your task. Must be either 'FARGATE' or 'EC2'
        """
    ).tag(config=True)    
        
    subnets = List(
        os.environ.get('TASK_SUBNETS', '').split(','),
        allow_none=True,
        help="""
        A list of subnets to place the task into.
        """        
    ).tag(config=True)

    security_group = Unicode(
        os.environ.get('TASK_SECURITY_GROUP', None),
        allow_none=True,
        help="""
        A security group to attach to the Task
        """        
    ).tag(config=True)

    platform_version = Unicode(
        None,
        allow_none=True,
        help="""
        The platform version the task should run.
        """
    ).tag(config=True)

    network_config = Dict(
        None,
        allow_none=True,
        help="""
        The network configuration for the task. 
        This parameter is required for task definitions that use the awsvpc network mode to 
        receive their own elastic network interface, and it is not supported for other network modes.
        """,
    ).tag(config=True)    

    tags = List(
        None,
        allow_none=True,
        help="""
        The network configuration for the task. 
        This parameter is required for task definitions that use the awsvpc network mode to 
        receive their own elastic network interface, and it is not supported for other network modes.
        """,
    ).tag(config=True)

    enable_ecs_managed_tags = Bool(
        False,
        help="""
        Specifies whether to enable Amazon ECS managed tags for the task.        
        """,
    ).tag(config=True)

    propagate_tags = Unicode(
        None,
        allow_none=True,
        help="""
        Specifies whether to propagate the tags from the task definition to the task. 
        If no value is specified, the tags are not propagated. Tags can only be propagated to the task during task creation. 
        To add tags to a task after task creation, use the TagResource API action.
        """,
    ).tag(config=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # All traitlets configurables are configured by now
        self.log.debug(f'Initializing ECS client in  region: {self.region}')
        self.ecs_client = boto3.client('ecs', region_name=self.region)
        self.ec2_client = boto3.client('ec2', region_name=self.region)

        # configure the network config if found
        self.log.debug(f'Network Config: {self.network_config}')
        self.log.debug(f'Subnets: {self.subnets}')
        self.log.debug(f'SecurityGroup: {self.security_group}')
        if not self.network_config and self.subnets and self.security_group:
            self.network_config = {
                'awsvpcConfiguration': {
                    'subnets': [
                        self.subnets.join(',')
                    ],
                    'securityGroups': [
                        self.security_group
                    ]
                }
            }
            self.log.debug(f'Created new network config object: {self.network_config}')

        self.log.debug('Initiated ECS spawer')
    
    def load_state(self, state):
        ''' Misleading name: this "loads" the state onto self, to be used by other methods '''

        super().load_state(state)

        # Called when first created: we might have no state from a previous invocation
        self.task_arn = state.get('task_arn', '')


    def get_state(self):
        ''' Misleading name: the return value of get_state is saved to the database in order
        to be able to restore after the hub went down '''

        state = super().get_state()
        state['task_arn'] = self.task_arn

        return state

    @gen.coroutine
    def start(self):
        self.log.debug(f'Starting new ECS task with Task Def Arn: {self.task_definition_arn}')
        yield self.start_task()

        response = yield self.get_task_state()
        eni = [i for i in response['tasks'][0]['attachments'][0]['details'] if i['name'] == 'networkInterfaceId'][0]['value']
        
        ip, port = yield self.get_ip_and_port(eni)
        return ip, port
     
    @gen.coroutine
    def stop(self, now=False):
        self.log.debug(f'Stopping ECS task with ARN: {self.task_arn}')
        response = self.ecs_client.stop_task(
            cluster=self.ecs_cluser_name,
            task=self.task_arn,
            reason='Task stopped by JupyterHub',
        )
        self.log.debug(f'StopTask response: {response}')

    @gen.coroutine
    def poll(self):
        self.log.debug(f'Getting status of Task Arn: {self.task_arn}')
        response = yield self.get_task_state()

        current_status = response['tasks'][0]['desiredStatus']
        self.log.debug(f'Current status  is {current_status}')

        if current_status in start_states:
            return None
        else:
            return 0

    @gen.coroutine
    def start_task(self):
        # launch the run_task command
        response = self.ecs_client.run_task(
            cluster=self.ecs_cluser_name,
            taskDefinition=self.task_definition_arn,
            networkConfiguration=self.network_config,
            launchType=self.launch_type,
            startedBy='ECS Spawner',
            count=1,
        )
        self.log.debug(f'RunTask response: {response}')
        self.task_arn = response['tasks'][0]['taskArn']
        self.log.debug(f'Task ARN is: {self.task_arn}')

        # wait for ECS task to be in RUNNING state
        self.log.debug(f'Waiting for task to be in running state....')
        waiter = self.ecs_client.get_waiter('tasks_running')
        waiter.wait(
            cluster=self.ecs_cluser_name,
            tasks=[
                self.task_arn,
            ],
        )
        self.log.debug(f'Task running')

    @gen.coroutine
    def get_task_state(self):
        response = self.ecs_client.describe_tasks(
            cluster=self.ecs_cluser_name,
            tasks=[self.task_arn],
        )
        self.log.debug(f'DescribeTasks response: {response}')
        return response     

    @gen.coroutine
    def get_ip_and_port(self, eni):
        response  = self.ec2_client.describe_network_interfaces(
            NetworkInterfaceIds=[eni]
        )
        self.log.debug(f'DescribeNetworkInterface response: {response}')
        return response['NetworkInterfaces'][0]['Association']['PublicIp'], 8888
