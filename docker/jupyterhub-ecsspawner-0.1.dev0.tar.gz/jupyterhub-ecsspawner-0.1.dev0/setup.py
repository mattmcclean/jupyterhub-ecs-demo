import setuptools

with open('README.md', 'r') as fh:
    long_description = fh.read()

setuptools.setup(
    name='jupyterhub-ecsspawner',
    version='0.1dev',
    author='Amazon Web Services',
    author_email='mmcclean@amazon.com',
    description='Spawns JupyterHub single user servers in Docker containers running in AWS ECS',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/mattmcclean/ecsspawner',
    packages=setuptools.find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: Apache Software License',
        'Operating System :: OS Independent',
    ],
    install_requires=[
        'jupyterhub>=0.9',
        'tornado>=5.0',
        'boto3>=1.9.151'
    ],
)