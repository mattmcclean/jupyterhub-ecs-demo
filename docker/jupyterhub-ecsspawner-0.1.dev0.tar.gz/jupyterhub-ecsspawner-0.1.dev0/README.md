# ecsspawner
A demo JupyterHub spawner that launches AWS Elastic Container Service Tasks
